package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    TableLayout tl_calcHolder;
    FloatingActionButton[][] fab_buttons;
    TextView[][] tv_buttonsText;
    EditText et_showEquations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fab_buttons = new FloatingActionButton[4][4];
        tv_buttonsText = new TextView[4][4];
        tl_calcHolder = findViewById(R.id.tl_calcHolder);
        et_showEquations = findViewById(R.id.et_showEquations);

        initializeFABsAndTVs();

    }



    private void initializeFABsAndTVs() {
        for(int i = 0; i < tl_calcHolder.getChildCount(); i++) {
            TableRow tableRow = (TableRow) tl_calcHolder.getChildAt(i);
            for(int j = 0; j < tableRow.getChildCount(); j++) {
                ConstraintLayout constraintLayout = (ConstraintLayout) tableRow.getChildAt(j);
                FloatingActionButton fab_button = (FloatingActionButton) constraintLayout.getChildAt(0);
                TextView tv_preview = (TextView) constraintLayout.getChildAt(1);
                fab_buttons[i][j] = fab_button;

                fab_button.setOnClickListener( v -> {
                    et_showEquations.setText(et_showEquations.getText() + tv_preview.getText().toString());
                });


                tv_buttonsText [i][j] = tv_preview;
                Log.d("button text", tv_preview.getText().toString());
            }
        }
    }
}